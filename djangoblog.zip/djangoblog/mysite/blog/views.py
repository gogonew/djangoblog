from django.shortcuts import render, get_object_or_404
from blog.models import Post
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.views.generic import ListView, DetailView
from .form import EmailPostForm, SignUpForm, LogInForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect


class PostListView(ListView):
    queryset = Post.published.all()
    context_object_name = 'posts'
    paginate_by = 3
    template_name = 'blog/post/list.html'




def post_list(request):
    object_list = Post.published.all()
    paginator = Paginator(object_list, 3)    #3 posts at single page
    page = request.GET.get('page')
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)


    return render(request, 'blog/post/list.html', {'page':page,'posts':posts})



# display single post
def post_detail(request, year, month, day, post):
    post = get_object_or_404(Post, slug=post, status='Published',
                             publish_year=year, publish_month=month, publish_day=day)
    return render(request, 'blog/post/detail.html', {'post': post})

# def post_share(request, post_id):
#     post = get_object_or_404(Post, id=post_id, status='published')
#     if request.method == 'POST':
#         form = EmailPostForm(request.POST)
#         if form.is_valid():
#             form.save()
#         else:
#             form = EmailPostForm()
#     return render(request, 'blog/post/shar.html', {'post':post, 'form':form})



# home

def home(request):
    posts = Post.objects.all()
    
    return render(request, 'blog/home.html', {'posts': posts})

# about
def about(request):
    return render(request, 'blog/about.html')

# contact
def contact(request):
    return render(request, 'blog/contact.html')    



# dashboard
def dashboard(request):
    return render(request, 'blog/dashboard.html')


# signup
def signup(request):
 if request.method == "POST":
     form = SignUpForm(request.POST)
     if form.is_valid():
         messages.success(request,'Thankyou soo much for signing up, start your journey by writing up a blog and inspire people around')
         form.save()
 else:
     form = SignUpForm()
 
 return render(request, 'blog/signup.html', {'form':form})   

# login  

def user_login(request):
 
 if not request.user.is_authenticated:
    if request.method == "POST":
        form = LogInForm(request=request, data=request.POST)
        if form.is_valid():
             uname = form.cleaned_data['username']
             upass = form.cleaned_data['password']
             user = authenticate(username=uname, password=upass)
             if user is not None:
                 login(request, user)
                 messages.success(request, 'Kudos you remembered it well !!')
                 return HttpResponseRedirect('/dashboard/')
    else:
      form = LogInForm()
    return render(request, 'blog/login.html', {'form':form})   
 else:
     return HttpResponseRedirect('/dashboard/')  



#logout
def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/')



class HomeView(ListView):
    model = Post
    template_name = 'home.html'


